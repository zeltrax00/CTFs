// gcc -fstack-protector-all -Wl,-z,relro,-z,now pwn2.c -o pwn2

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int init()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    time_t rawtime;
    time(&rawtime);
    struct tm *tm_struct = localtime(&rawtime);
    int hour = tm_struct->tm_hour;
    int minute = tm_struct->tm_min;
    printf("[%d:%d] Detect Intrusion !!!\n", hour, minute);
    int seed = hour * (minute / 15 + 1);
    return seed;
}

int main(void)
{
    int n = 0;
    char buf[80];
    srand(init());

    printf("Please provide your certification.\n");
    for (int i = 0; i < 16; ++i)
    {
        printf("Enter your private number: ");
        int x = rand();
        scanf("%d", &n);
        int c; while ((c = getchar()) != EOF && c != '\n') {}

        if (n == x)
            printf("Correct. Next.\n");
        else
        {
            printf("Wrong. Guardians, catch him.\n");
            exit(0);
        }
    }

    printf("You are authenticated.\nWhat can I help you ?\n");
    fgets(buf, 80, stdin);
    printf(buf);
    printf("\nAre you sure to do that ? ");
    fgets(buf, 160, stdin);
    printf("\nOK, done\n");


    return 0;
}
