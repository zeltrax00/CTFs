//g++ -m32 -no-pie -fstack-protector-all pwn1.cpp -o pwn1
#include <iostream>
#include <fstream>
#include <random>
#include <signal.h>
#include <unistd.h>

typedef void (*voidfunc)();

void win()
{
	std::string flag;
	std::ifstream ifs("flag.txt", std::ifstream::in);
	std::getline(ifs, flag);

	std::cout << flag << std::endl;

	ifs.close();
	exit(0);
}

void kill_on_timeout(int sig) {
  if (sig == SIGALRM) {
    _exit(0);
  }
}


void init(uint64_t *p, uint32_t **pn)
{
	setvbuf(stdout, NULL, _IONBF, 0);
    	setvbuf(stderr, NULL, _IONBF, 0);
    	signal(SIGALRM, kill_on_timeout);
	alarm(30);

	std::random_device rd;

	/* Random number generator */
	std::default_random_engine generator(rd());
	*pn = (uint32_t *)p;
	
	/* Distribution on which to apply the generator */
	std::uniform_int_distribution<long long unsigned> distribution(0x1111111111111111,0xFFFFFFFFFFFFFFFF);
	*pn = (uint32_t *)((char*)*pn + 2);
	
	for (int i = 0; i < 10; i++) {
		*p = distribution(generator);
	}
}

void menu()
{
	std::cout << "Select an action: \n"
				<< "1. Add\n"
				<< "2. Crash" << std::endl;


}

void add(uint64_t *p)
{
	std::cout << "Input number to add: ";
	uint64_t addn = 0;
	std::string s;
	std::getline(std::cin, s);
	if (s.empty())
		return;
	addn = std::strtoull(s.c_str(), NULL, 10);
	*p = *p + addn;
	
}

int main(void)
{
	uint64_t number = 69;
	uint32_t* p = 0;
	init(&number, &p);

	while (true)
	{
		std::cout << "\nMagic number: " << number << std::endl;
		
		menu();
		std::string s;
		std::getline(std::cin, s);
		if (s.empty())
			continue;
		unsigned long c = std::strtoul(s.c_str(), NULL, 10);

		if (c == 1)
		{
			add(&number);
		}
		else if (c == 2)
		{
			std::cout << "Crashing...\n";
			reinterpret_cast<voidfunc>(*p)();
		}
		else
			continue;
	}

	return 0;
}
