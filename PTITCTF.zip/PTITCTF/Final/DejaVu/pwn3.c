//gcc -m32 -no-pie -fno-stack-protector -o pwn3 pwn3.c

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char *s = "This is a WTF challenge!\nJust do it ... \n";
char *p = " *** hieu kieu gi :(( ";

void vuln(){
    char buf[0x20];
    read(0, buf, 0x60);
}
  
void main(){
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
	
    int i = 0;
    for (i = 0; i < strlen(s); ++i)
        putchar(s[i]);

    vuln();

}

