#!/bin/bash
while true;
do
sudo docker kill pwn1
sudo docker rm pwn1
sudo docker kill pwn2
sudo docker rm pwn2
sudo docker kill pwn3
sudo docker rm pwn3
sudo docker run -d --name=pwn1 -p 0.0.0.0:6966:6966 pwn1
sudo docker run -d --name=pwn2 -p 0.0.0.0:6967:6967 pwn2
sudo docker run -d --name=pwn3 -p 0.0.0.0:6969:6969 pwn3
sleep 60
done;
