//gcc pwn2.c -m32 -no-pie -o pwn2

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char *s = "This is a WTF challenge!\nJust do it ... \n";
char *p = " *** hieu kieu gi :(( ";

void vuln(){
    char buf[0x20];
    read(0, buf, 0x60);
}
  
void main(){
	setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
	
    printf("%s", s);

    vuln();
}